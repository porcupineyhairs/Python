# -*- coding: utf-8 -*-
import importlib
import sys
import time


class Sockethandler:
	def __init__(self):
		self.__Module = None
		self.__ModuleNameSort = ''
		self.__ModuleName = ''
		self.__Recv_data = ''
		self.__GetBack = None

	def __doc__(self):
		pass

	# 根据从server中传入的值执行判断
	def judge(self, Recv_data=None):
		self.__init__()
		self.__Recv_data = Recv_data
		print(time.ctime(), 'Recv Info :')
		print(self.__Recv_data)
		self.__judgeWork()
		return self.__GetBack

	# 从字典中取出对应功能的模块名
	def __judgeWork(self):
		import LIB.ModuleDictionary
		try:
			self.__ModuleNameSort = LIB.ModuleDictionary.Module_Dict.get(self.__Recv_data)
			self.__ModuleSelect()
		except TypeError:
			print(time.ctime(), 'Not Found Function:', self.__Recv_data)

	# 根据模块名加载模块并执行任务
	def __ModuleSelect(self):
		self.__ModuleName = 'LIB.' + self.__ModuleNameSort
		try:
			# 根据请求命令动态调用模块
			self.__Module = importlib.import_module(self.__ModuleName)
			print(time.ctime(), 'Use Module Name: ', self.__ModuleName)
			# 重新加载模块，需提交两次请求才能更新为新的模块
			# reload(self.__Module)

			self.__ModuleMain = self.__Module.Main()
			self.__GetBack = self.__ModuleMain.MainWork()
			print(time.ctime(), 'Mission Completed')
			# 反import模块，需提交两次请求才能更新为新的模块
			print(time.ctime(), 'Un-import Module:', self.__ModuleName)
			del sys.modules[self.__ModuleName]
		except ModuleNotFoundError as Error:
			print(time.ctime(), 'Not Found Module!', Error)
		finally:
			print(time.ctime(), 'Done! ')
