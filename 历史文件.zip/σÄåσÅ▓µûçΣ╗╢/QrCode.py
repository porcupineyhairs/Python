# -*- coding:utf8 -*-

import qrcode
import PIL

if __name__ == '__main__':
	url = '打开这个链接http://192.168.31.136:8099？CF-CM-01'

	# 初始化二维码生成器
	qr = qrcode.QRCode(
		version=1,  # 设置容错率为最高
		error_correction=qrcode.ERROR_CORRECT_H,  # 用于控制二维码的错误纠正程度
		box_size=8,  # 控制二维码中每个格子的像素数，默认为10
		border=1,  # 二维码四周留白，包含的格子数，默认为4
		# image_factory=None,  # 保存在模块根目录的image文件夹下
		# mask_pattern=None
		)
	# 填入在二维码中保存的数据
	qr.add_data(url)
	qr.make(fit=True)

	qr = qr.make_image()
	qr = qr.convert('RGBA')
	logo = PIL.Image.open(r'./Src/Img/logo.png')

	qr_width, qr_height = qr.size
	face_image = logo.resize((100, 100), PIL.Image.ANTIALIAS)

	# 将头像嵌入二维码当中
	qr.paste(face_image, ((qr_width - 100) // 2, (qr_height - 100) // 2))
	qr.save(r'qrcode.png')
