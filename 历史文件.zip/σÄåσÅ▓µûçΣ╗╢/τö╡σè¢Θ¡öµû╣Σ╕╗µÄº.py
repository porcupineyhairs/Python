# -*- coding: utf-8 -*-
import socket
from socketserver import TCPServer, StreamRequestHandler  # , ForkingMixIn
import sqlite3
import time
import os
import multiprocessing

send_port = 6544
master_port = 6543
master_addr = ''


class SQL:
	def __init__(self):
		pass

	def open(self):
		# 连接数据库
		try:
			self.conn = sqlite3.connect("./database/DB.shuju")
		except():
			pass

	# 根据设备号（前三位）获取设备系列（另一个表）
	def get_ID(self, ID):
		self.ID = ID
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select name from ID where devID=\'" + str(self.ID) + "\'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.res = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		for self.f in self.res:
			self.strlist = str(self.f).split('\'')
			self.strlist = self.strlist[1]
		return self.strlist

	# 更新设备IP（设备启动连入，设备号已存在数据库）
	def update_IP(self, devID, IP):
		self.IP = IP
		self.devID = devID
		self.open()
		# 更新IP
		self.sqlcmd = "update status set IP=\'" + str(self.IP) + "\' where devID=\'" + str(self.devID) + "\'"
		self.conn.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 更新状态
		self.sqlcmd = "update status set status='onl' where devID=\'" + str(self.devID) + "\'"
		self.conn.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		self.conn.close()
		return

	# 根据设备号获取设备名
	def get_name(self, devID):
		self.devID = devID
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select name from status where devID=\'" + str(self.devID) + "\'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.name = self.cur.fetchall()
		# 使用游标查询数据
		self.sqlcmd = "select NO from status where devID=\'" + str(self.devID) + "\'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.NO = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		for self.f in self.name:
			self.strlist1 = str(self.f).split('\'')
			self.name = self.strlist1[1]
		for self.f in self.NO:
			self.strlist2 = str(self.f).split('\'')
			self.NO = self.strlist2[1]
		self.rtn = str(self.name) + '.' + str(self.NO)
		return self.rtn

	# 查询设备号存在情况（设备启动连入时）
	def get_devID(self, devID):
		self.devID = devID
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select devID from status where devID=\'" + str(self.devID) + "\'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.res = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		try:
			for self.f in self.res:
				self.strlist = str(self.f).split('\'')
				self.strlist = self.strlist[1]
			return self.strlist
		except AttributeError:
			return 'error'

	# 更新设备状态
	def update_stasus(self, name, NO, status):
		self.name = name
		self.status = status
		self.NO = NO
		self.open()
		# 更新状态
		self.sqlcmd = "update status set status=\'" + str(self.status) + "\' where name=\'" + str(
			self.name) + "\'" + " and NO=\'" + str(self.NO) + "\'"
		self.conn.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		self.conn.close()
		return

	# 新增设备
	def insert(self, name, NO, devID, IP, status):
		self.name = name
		self.NO = NO
		self.devID = devID
		self.IP = IP
		self.status = status
		self.open()
		# 插入数据
		self.sqlcmd = "insert into status (name, NO, devID, IP, status) values (\'" + str(self.name) + "\', \'" + str(
			self.NO) + \
					  "\', \'" + str(self.devID) + "\', \'" + str(self.IP) + "\', \'" + str(self.status) + "\');"
		self.conn.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		self.conn.close()
		return

	# 删除设备
	def delete(self, name, NO):
		self.name = name
		self.NO = NO
		self.open()
		# 删除数据
		self.sqlcmd = "delete from status where name=\'" + str(self.name) + "\'" + "and NO=\'" + str(self.NO) + "\'"
		self.conn.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		self.conn.close()
		return

	# 获取设备最大序号（新增设备时）
	def get_NO(self, name):
		self.name = name
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select NO from status where name=\'" + str(self.name) + "\'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.res = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		# 获取最大设备号
		self.cmp = 0
		try:
			for self.f in self.res:
				self.strlist = str(self.f).split('\'')
				self.strlist = self.strlist[1]
				if ((int(self.strlist)) > int(self.cmp)):
					self.cmp = self.strlist
		except:
			pass
		return self.cmp

	# 获取设备IP（指令转发时）
	def get_IP(self, name, NO):
		self.name = name
		self.NO = NO
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select IP from status where name=\'" + str(self.name) + "\'" + "and NO=\'" + str(self.NO) + "\'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.res = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		for self.f in self.res:
			self.strlist = str(self.f).split('\'')
			self.strlist = self.strlist[1]
		return self.strlist

	# 暂时没有用到
	def get_status(self, name, NO):
		self.name = name
		self.NO = NO
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select status from status where name=\'" + str(self.name) + "\'" + "and NO=\'" + str(
			self.NO) + "\'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.res = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		for self.f in self.res:
			self.strlist = str(self.f).split('\'')
			self.strlist = self.strlist[1]
		return self.strlist

	# 获取设备状态（手机刷新时、屏幕启动时）
	def get_all(self):
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select name, NO, status from status "
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.res = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		# 字符串整理成特定格式输出
		self.strlist = ''
		for self.line in self.res:
			for self.f in self.line:
				self.strlist = self.strlist + str(self.f) + '.'
			self.strlist = self.strlist + ','
		self.strlist = self.strlist.replace('.,', ',').rstrip(',')
		return self.strlist

	# 获取设备状态
	def get_name_onl(self):
		self.open()
		# 获取游标对象
		self.cur = self.conn.cursor()
		# 使用游标查询数据
		self.sqlcmd = "select name, NO from status where status='onl'"
		self.cur.execute(self.sqlcmd)
		# 手动提交数据
		self.conn.commit()
		# 获取所有结果
		self.res = self.cur.fetchall()
		# 关闭连接
		self.cur.close()
		self.conn.close()
		# 字符串整理成特定格式输出
		self.strlist = ''
		for self.line in self.res:
			for self.f in self.line:
				self.strlist = self.strlist + str(self.f) + '.'
			self.strlist = self.strlist + ','
		self.strlist = self.strlist.replace('.,', ',').rstrip(',')
		return self.strlist


# 专门与IOS进行通讯的类
class PHONE:
	def __init__(self):
		self.sql = SQL()
		self.run()

	def run(self):
		status = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 生成socket对象
		status.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
		status.bind((master_addr, 6545))  # 绑定socket地址
		status.listen(3)  # 开始监听
		while True:
			c, addr = status.accept()  # 接受一个连接
			if c:
				# 打印客户端地址
				self.peer_ip = self.string_handel1(addr)
				print('Get connection from :', self.peer_ip)
				data = c.recv(1024)
				print(data)
				send = self.sql.get_all()
				print(send)
				send = str(send).encode('utf-8')
				c.send(send)  # 发送数据
				c.close()  # 关闭连接

	def string_handel1(self, strlist1):
		self.strlist1 = str(strlist1).split('\'')
		self.strlist1 = self.strlist1[1]
		return self.strlist1


# 获取设备状态（2s工作一次）
class GETSTATUS:
	def __init__(self):
		self.sql = SQL()
		self.run()

	def socket_send(self, addr, cmd):
		self.addr = addr
		self.cmd = str(cmd).encode('utf-8')
		try:
			self.s = socketsvr.socketsvr()
			self.s.settimeout(0.5)
			self.s.connect((str(self.addr), 6544))
			self.s.settimeout(0.5)
			self.s.send(bytes(self.cmd))
			self.s.close()
			return ' has send\n'
		except TimeoutError:
			self.sql.update_stasus(str(self._name_[0]), str(self._name_[1]), 'ofl')
			return 'timeout\n'
		except ConnectionRefusedError:
			self.sql.update_stasus(str(self._name_[0]), str(self._name_[1]), 'ofl')
			return 'refused\n'
		except OSError:
			self.sql.update_stasus(str(self._name_[0]), str(self._name_[1]), 'ofl')
			return 'oserror\n'

	def network(self):
		self.name = str(self.sql.get_name_onl()).split(',')
		# print(self.name)
		for self._name in self.name:
			print(self._name)
			self._name_ = str(self._name).split('.')
			try:
				self.addr = self.sql.get_IP(str(self._name_[0]), str(self._name_[1]))
				print(self.addr)
				self.getreturn = self.socket_send(str(self.addr), str('STATUS'))
				print(str(self._name) + ',' + str(self.getreturn))
			except IndexError:
				print('IndexError\n')
				pass

	def run(self):
		while True:
			print('get_status')
			time.sleep(2)
			self.network()


# 这个类不用管
# class Server(ForkingMixIn, TCPServer):  # 自定义Server类
class Server(TCPServer):  # 自定义Server类
	pass


class MyHandler(StreamRequestHandler):
	def handle(self):  # 重载handle函数
		# 打印客户端地址
		self.peer_ip = self.string_handel1(self.request.getpeername())
		print('Get connection from :', self.peer_ip)
		# 获取数据包的内容（去b'...'）
		self.data = self.request.recv(1024).strip()
		print(self.data)
		print(self.string_handel1(self.data))
		# 命令处理
		self.network(self.string_handel1(self.data))

	def socket_send(self, addr, cmd):
		self.addr = addr
		print(self.addr + ', ' + cmd)
		self.cmd = str(cmd).encode('utf-8')
		self.s = socket.socket()
		self.s.connect((str(self.addr), send_port))
		self.s.send(bytes(self.cmd))
		self.s.close()
		print('comp')

	def network(self, i):
		self.sql = SQL()
		# 按 '.' 进行切片处理
		i = self.string_handel2(i)
		if i[0] == 'CONTROL':
			self.send_addr = self.sql.get_IP(i[1], i[2])
			self.socket_send(self.send_addr, str(i[3]) + '.')

		if i[0] == 'INIT':
			self.devID = str(self.sql.get_devID(i[1]))
			print(i[1])
			if (i[1] == self.devID):
				self.sql.update_IP(i[1], self.peer_ip)
				self.sql.update_status(str(self.sql.get_name(i[1])))
				self.send = 'NAME.' + str(self.sql.get_name(i[1]))
				time.sleep(0.1)
				self.socket_send(self.peer_ip, self.send)
			if (self.devID == 'error'):
				self.name = self.sql.get_ID(str(i[1])[0:3])
				print(self.name)
				self.NO = int(self.sql.get_NO(self.name)) + 1
				self.sql.insert(self.name, self.NO, i[1], self.peer_ip, 'onl')
				self.send = 'NAME.' + str(self.name) + '.' + str(self.NO)
				time.sleep(0.1)
				self.socket_send(self.peer_ip, self.send)

		if i[0] == 'DEL':
			self.sql.delete(i[1], i[2])
			pass

		if i[0] == 'STATUS':
			# if (i[1] == 'FAN'):
			#     self.status_send('FAN.ON')
			# if (i[1] == 'AUDIO'):
			#     self.status_send('AUDIO.ON')
			pass

		if i[0] == 'SCREEN':
			self.screen_addr = self.peer_ip
			self.send = str(self.sql.get_all())
			time.sleep(0.2)
			self.socket_send(self.screen_addr, self.send)

		if i[0] == 'PHONE':
			self.phone_addr = self.peer_ip
			self.send = self.sql.get_all()
			print(self.send)
			self.send = str(self.send).encode('utf-8')
			time.sleep(0.2)
			self.s = socket.socket()
			self.s.connect((str(self.phone_addr), 6543))
			self.s.settimeout(1)
			self.s.send(bytes(self.send))
			self.s.close()

		del self.sql

	def string_handel1(self, strlist1):
		self.strlist1 = str(strlist1).split('\'')
		self.strlist1 = self.strlist1[1]
		return self.strlist1

	def string_handel2(self, strlist2):
		self.strlist2 = str(strlist2).split('.')
		return self.strlist2


if __name__ == '__main__':
	__author = 'Author:Harvey.Z\nConnection:295888245@qq.com'
	# 获取本地IP
	# Linux
	# master_addr = os.popen(
		# "ifconfig | grep 'inet addr:' | grep -v '127.0.0.1' | cut -d: -f2 | awk '{print $1}' | head -1").read()
	# MAC
	master_addr = os.popen(
		"ifconfig | grep 'inet' |grep -v 'inet6'|grep -v '127.0.0.1' |cut -d: -f2| awk '{print $2}'| head -1").read()
	# WIN
	# master_addr = os.popen(
	# 	"")
	print(master_addr)
	master_addr = master_addr.strip('\n')
	# master_addr = '192.168.31.29'
	print('\n' + __author + '\n')
	print('Time is ' + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()) + '\n')

	process = multiprocessing.Process(target=GETSTATUS)
	process.start()
	process2 = multiprocessing.Process(target=PHONE)
	process2.start()

	server = Server((str(master_addr), master_port), MyHandler)
	print('socket')
	server.serve_forever()
