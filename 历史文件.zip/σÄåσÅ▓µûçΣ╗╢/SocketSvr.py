# -*- coding: utf-8 -*-
from socketserver import TCPServer, StreamRequestHandler
from SocketHandler import Sockethandler
import time


# 这个类不用管
class Server(TCPServer):  # 自定义Server类
	pass


class MyHandler(StreamRequestHandler):
	def handle(self):  # 重载handle函数
		# 打印客户端地址
		self.peer_ip = str(self.request.getpeername()).split('\'')[1]
		print()
		print(time.ctime(), 'Get connection from :', self.peer_ip)
		# 获取数据包的内容
		self.data_recv = self.request.recv(8192).strip().decode()
		self.Handler = Sockethandler()
		self.GetBack = self.Handler.judge(self.data_recv)
		self.request.sendall(bytes(str(self.GetBack).encode(encoding='utf-8')))


if __name__ == '__main__':
	# 常量定义
	master_port = 6543
	from SelfModule import Normal
	normal = Normal()
	# 获取电脑IP
	master_addr = normal.getlocalip()
	print(master_addr)
	# 清除不再使用的变量
	del Normal
	del normal

	try:
		server = Server((str(master_addr), master_port), MyHandler)
		print()
		print(time.ctime(), 'SocketServer Start Successful!', master_addr, '\n')
		server.serve_forever()
	except KeyboardInterrupt:
		server.shutdown()
		print()
		print(time.ctime(), 'SocketServer Stop By KeyboardInterrupt!\n')
