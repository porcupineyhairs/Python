# -*- coding: utf-8 -*-
Module_Dict = {
	'TestModule': 'TestModule',
	'BOMSelect': 'BOMSelect',
	'BOMCompare': 'BOMCompare',
	'CPPZSelect': 'CPPZSelect'
}

DataBase_Dict = {
	'CONFIG': ['192.168.0.198', 'sa', 'COMfort123456', 'CONFIG'],
	'ROBOT': ['192.168.0.198', 'sa', 'COMfort123456', 'ROBOT'],
	'ROBOT_TEST': ['192.168.0.198', 'sa', 'COMfort123456', 'ROBOT_TEST'],

	'TEST2018': ['192.168.0.99', 'sa', 'comfortgroup2016{', 'TEST2018'],
	'COMFORT': ['192.168.0.99', 'sa', 'comfortgroup2016{', 'COMFORT']
}
